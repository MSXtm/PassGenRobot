# Token of your bot (get from @BotFather)
token = "1171340815:AAEGBIHkW6cClFzYUiijU_by7AhAc7YN_go"

# Json file with all data
db_file = "database.json"

# List of words used to generate passwords
words_file = "wrds.txt"

# Minimum/maximum allowed words in password
length_min = 2
length_max = 8
